package app.num.piechart;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.HorizontalBarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

/*
        PieChart pieChart = (PieChart) findViewById(R.id.chart);

        ArrayList<Entry> entries = new ArrayList<>();
        entries.add(new Entry(4f, 0));
        entries.add(new Entry(8f, 1));
        entries.add(new Entry(6f, 2));
        entries.add(new Entry(12f, 3));
        entries.add(new Entry(18f, 4));
        entries.add(new Entry(9f, 5));

        PieDataSet dataset = new PieDataSet(entries, "# of Calls");

        ArrayList<String> labels = new ArrayList<String>();
        labels.add("January");
        labels.add("February");
        labels.add("March");
        labels.add("April");
        labels.add("May");
        labels.add("June");

        PieData data = new PieData(labels, dataset);
        dataset.setColors(ColorTemplate.COLORFUL_COLORS); //
        pieChart.setDescription("Description");
        pieChart.setData(data);

        pieChart.animateY(5000);

        pieChart.saveToGallery("/sd/mychart.jpg", 85); // 85 is the quality of the image
*/



        // Inicijalizacija dijagrama
        HorizontalBarChart pieChart = (HorizontalBarChart) findViewById(R.id.bar_chart);

        // ArrayList koji sadrži nazive tlakova za legendu
        ArrayList<String> labels = new ArrayList<String>();
        // ArrayList koji sadrži instance pojedinih izmjerenih tlakova
        List<BarEntry> entries = new ArrayList<>();


            entries.add(new BarEntry(15, 0));
            labels.add("Optimalni");



            entries.add(new BarEntry(16, 1));
            labels.add("Normalni");



            entries.add(new BarEntry(26, 2));
            labels.add("Povišeni");

            entries.add(new BarEntry(30, 3));
            labels.add("Visoki");

            entries.add(new BarEntry(35, 4));
            labels.add("Dosta visoki");

            entries.add(new BarEntry(47, 5));
            labels.add("Hipertenzija");

            entries.add(new BarEntry(58, 6));
            labels.add("Izolirani");

        // Unos prikupljenih podataka u PieDataSet
        BarDataSet dataset = new BarDataSet(entries, "ddd");



        BarData data = new BarData(labels, dataset);
        dataset.setColors(ColorTemplate.JOYFUL_COLORS);
        pieChart.setDescription("Legenda");
        pieChart.setData(data);

        //pieChart.setCenterText("Prosjek krvnog tlaka (%)");
        //pieChart.setHoleRadius(20);


        pieChart.animateX(1000);



    }
}
